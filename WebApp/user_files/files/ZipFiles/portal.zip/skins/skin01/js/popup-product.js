$(function()
{
  var hideDelay = 100;  
  var currentID;
  var hideTimer = null;
  var offSetX = 20;
  var offSetY = -30;
  
  // One instance that's reused to show info for the current person
  var container = $('<div id="productPopupContainer">'
	  + '<table width="" border="0" cellspacing="0" cellpadding="0" align="center" class="productPopupPopup">'
	  + '<tr>'
	  + '   <td class="corner topLeft"></td>'
	  + '   <td class="top"></td>'
	  + '   <td class="corner topRight"></td>'
	  + '</tr>'
	  + '<tr>'
	  + '   <td class="left">&nbsp;</td>'
	  + '   <td><div id="productPopupContent"></div></td>'
	  + '   <td class="right">&nbsp;</td>'
	  + '</tr>'
	  + '<tr>'
	  + '   <td class="corner bottomLeft">&nbsp;</td>'
	  + '   <td class="bottom">&nbsp;</td>'
	  + '   <td class="corner bottomRight"></td>'
	  + '</tr>'
	  + '</table>'
	  + '</div>');

	$('body').append(container);
	
	$('.productPopupTrigger').live('mouseover', function(e)
	{
		// format of 'rel' tag: pageid,personguid
		currentID = $(this).attr('rel');
	
		// If no guid in url rel tag, don't popup blank
		if (currentID == '')
			return;
	
		if (hideTimer)
			clearTimeout(hideTimer);
		
		setPositionTooltip(e);
		
		var popupContent = $('#' + currentID);
		$('#productPopupContent').html(popupContent.html());
		
		container.css('display', 'block');
	});

	$('.productPopupTrigger').live('mouseout', function()
	{
		if (hideTimer)
		  clearTimeout(hideTimer);
		hideTimer = setTimeout(function()
		{
			container.css('display', 'none');
		}, hideDelay);
	});

	$('.productPopupTrigger').live('mousemove', function(e){
		setPositionTooltip(e);
	});
	
	function setPositionTooltip(e){
		var x=e.pageX+offSetX;
		var y=e.pageY+offSetY;
		var tipw=container.outerWidth();
		var tiph=container.outerHeight();
		x=(x+tipw>$(document).scrollLeft()+$(window).width())? x-tipw-(offSetX*2) :x;
		y=(y+tiph>$(document).scrollTop()+$(window).height())? $(document).scrollTop()+$(window).height()-tiph-10:y;
		container.css({left:x, top:y});
	}
	
/*
  // Allow mouse over of details without hiding details
  $('#productPopupContainer').mouseover(function()
  {
	  if (hideTimer)
		  clearTimeout(hideTimer);
  });

  // Hide after mouseout
  $('#productPopupContainer').mouseout(function()
  {
	  if (hideTimer)
		  clearTimeout(hideTimer);
	  hideTimer = setTimeout(function()
	  {
			container.css('display', 'none');
	  }, hideDelay);
  });
*/

});